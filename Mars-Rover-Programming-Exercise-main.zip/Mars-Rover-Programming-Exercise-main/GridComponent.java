
interface GridComponent {
    boolean isWithinBounds(int x, int y);
    boolean hasObstacle(int x, int y);
}
